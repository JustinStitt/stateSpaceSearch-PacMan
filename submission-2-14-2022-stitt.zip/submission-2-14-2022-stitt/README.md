Team members: Justin Stitt (jkstitt@csu.fullerton.edu, 888148632) (solo)
Submission: 2/14/2022 ~ 23:00

#### Passes Questions 1 and 2 ####
python autograder.py -q q1
python autograder.py -q q2



included:
search.py
README.md (this)
